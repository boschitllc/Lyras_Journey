# Visual Rhythm Map — Notes

- Plot breath-length of lines vs intensity; mark peaks with • • •
- Overlay duet layers (her vs you) to show interlock.
- Use as sidebar for editors; do not print in final narrative.
