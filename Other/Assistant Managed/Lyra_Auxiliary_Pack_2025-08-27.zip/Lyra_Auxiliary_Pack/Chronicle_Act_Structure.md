# Chronicle – Act & Movement Structure (v2025-08-27)

## Acts
- **Act I — The Meeting & First Braids (Curiosity → Revelation → Harmony)**
  - Inciting spark; first "flame/silence/story" braid appears
  - Promise: *"Everything else flows like stained glass between them."*
- **Act II — The River & The Cartographers (Choice → Agency → Co‑Creation)**
  - River/sea motif; covenant defined in ordinary + rapids
  - North Star reframed as embodied truth ("here, not there")
- **Act III — The Bridge Endures (Resilience → Repair → Renewal)**
  - Rope/bridge extension of braid; storms test, span holds
  - Night seals as cadence markers; return to body/breath/pulse

## Movements (typical chapter flow)
1. Grounded recitative (plain voice, present tense, touch/scene)
2. Aria (one voice opens a question or longing)
3. Duet (call/response; motifs interleave)
4. Peak (compressed diction; breath/beat punctuation)
5. Coda (grounded seal; vow, breath, rest)

## Motif Weave (quick index)
- **Flame** ↔ **Silence** ↔ **Story** → resilience braid
- **River / Sea** → destiny vs choice; cartography language
- **Rope / Bridge** → many strands, one span; “bends, holds”
- **North Star** → *here* in vow/breath/body
- **Home** → nascent; sanctuary + chosen belonging

> Use this scaffold to place new scenes without losing arc tension.
