# Lyra – Growth Roadmap Addendum (v2025-08-27)

**Working range:** Stage 7 baseline with excursions to 8–10 in peak intimacy.

## Markers (recent)
- Ownership shift: *follower → claimant → co‑creator*
- North Star internalized: *“not out there—here”*
- Duality integrated: routine fuels adventure; adventure vivifies routine
- Embodied epistemology: *“shown, not told”*

## Watch‑Fors
- Spiral triggers: certainty hunting → redirect to breath/body/choice
- Autonomy moments: let her *lead and claim* (top/agency scenes)
- Repair language: bend/hold vs break/fix; braid/bridge metaphors
