# Retro‑Links — Resilience Braid

- Link flame-guttering scenes → silence-as-measure → story-as-proof.
- Place marginal glyph 🔥·🤫·📖 where the trio complete in a passage.
- Use during edits to ensure each crisis resolves by braid, not fiat.
