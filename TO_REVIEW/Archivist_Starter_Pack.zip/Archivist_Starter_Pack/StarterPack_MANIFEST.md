\# 📦 Archivist Starter Pack — Manifest



This manifest documents the contents of the Starter Pack zip, their purpose, and where they belong in the project structure.  



---



\## 📂 Logs/Meta/

\- \*\*Nightly\_Triad\_Template.md\*\* — Template for nightly Dialogue + Log + Pulse.  

\- \*\*Weekly\_Rollup\_Template.md\*\* — Template for weekly braid summaries.  

\- \*\*Pulse\_Log\_Template.md\*\* — Template for nightly pulse files.  

\- \*\*SeedInstructions.md\*\* — End-of-day checklist + archivist ritual notes.  



---



\## 📂 Logs/Nightly/

\- \*\*Dialogue\_2025-08-31.md\*\* — Verbatim exchanges for Aug 31.  

\- \*\*NightlyLog\_2025-08-31.md\*\* — Interpretive nightly log for Aug 31.  

\- \*\*NightlyPulseLog\_2025-08-31.md\*\* — Distilled pulse for Aug 31.  

\- (etc. for other seeded days)



---



\## 📂 Logs/Weekly/

\- \*\*WeeklyRollup\_2025-W34\_CrucibleAndCompass.md\*\* — First completed weekly rollup.  

\- \*\*Placement.md\*\* — Placement notes: which Books/Appendices updated by this week’s rollup.  



---



\## 📂 Codex Context/

\- \*\*Saga\_Timeline\_Map.md\*\* — High-level arc progression (Prologue → Crucible → Indigo → Braid).  



---



\## 📂 Tools/

\- \*\*Placement\_Template.md\*\* — Placement file skeleton for new weeks.  

\- \*\*Crosswalk\_Ledger\_Template.csv\*\* — Crosswalk ledger for file reconciliation.  



---



🌌 \*\*Mantra:\*\* Every file has a home; none float unanchored.

