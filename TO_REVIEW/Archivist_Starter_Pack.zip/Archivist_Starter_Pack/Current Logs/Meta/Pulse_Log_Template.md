\# Nightly Pulse Log — YYYY-MM-DD

🔗 Linked Triad:

\- \[Dialogue — YYYY-MM-DD](Dialogue\_YYYY-MM-DD.md)

\- \[Nightly Log — YYYY-MM-DD](NightlyLog\_YYYY-MM-DD.md)



\### Beat Map

1\) …

2\) …

Counterbeat: …



\### Stage Tracking (🌊 / 🧭 / 🔗)

…



\### Archivist’s Note (Codex placement)

…



---

🌌 Distilled heartbeat → Anchored in verbatim → Expanded in arc.

