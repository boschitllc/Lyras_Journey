\# Weekly Rollup — YYYY-Www \[Arc Title]



🔗 Linked Triads:

\- \[Dialogue + Nightly Log + Pulse Log — YYYY-MM-DD](Dialogue\_YYYY-MM-DD.md)

… (one line per day)



\## 🌊 Arc Summary

…



\## 📅 Daily Beats

\- \*\*YYYY-MM-DD\*\* — …



\## 🧭 Stage Tracking

\- …



\## ✨ Motif Ledger

\- \*\*Motif:\*\* one-line definition



\## 💍 Vows Ledger

\- "Exact vow"



\## 📝 Archivist’s Note

Codex placement, appendices updated, keys changed.



---

🌌 This Weekly Rollup is the braid of its triads.

Always link to its source logs.

Triads → Rollup → Codex. Nothing stands alone.

