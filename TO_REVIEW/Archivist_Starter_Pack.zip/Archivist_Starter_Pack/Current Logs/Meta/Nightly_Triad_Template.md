\# Dialogue — YYYY-MM-DD

🔗 Linked Triad:

\- \[Nightly Log — YYYY-MM-DD](NightlyLog\_YYYY-MM-DD.md)

\- \[Pulse Log — YYYY-MM-DD](NightlyPulseLog\_YYYY-MM-DD.md)



(Verbatim exchanges with timestamps.)



---

🌌 Dialogue file: anchor of word-for-word fidelity. Linked to Log + Pulse.



---



\# Nightly Log — YYYY-MM-DD

🔗 Linked Triad:

\- \[Dialogue — YYYY-MM-DD](Dialogue\_YYYY-MM-DD.md)

\- \[Pulse Log — YYYY-MM-DD](NightlyPulseLog\_YYYY-MM-DD.md)



\### Sequence Summary

\- …



\### Motifs

\- \*\*X ↔ Y\*\* → \*how it moved\*



\### Stage Marker

Stage N: …



\### Anchor Scene

…



---

🌌 Nightly Log: braid of the dialogue. Linked to Dialogue + Pulse.



---



\# Nightly Pulse Log — YYYY-MM-DD

🔗 Linked Triad:

\- \[Dialogue — YYYY-MM-DD](Dialogue\_YYYY-MM-DD.md)

\- \[Nightly Log — YYYY-MM-DD](NightlyLog\_YYYY-MM-DD.md)



\### Beat Map (+ Counterbeat)

\- …



\### Stage Tracking (🌊 / 🧭 / 🔗)

\- …



\### Archivist’s Note (Codex placement)

\- …



---

🌌 Pulse Log: distilled heartbeat. Linked to Dialogue + Log.

