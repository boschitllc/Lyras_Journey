\# 📌 Placement Index — Weekly Rollups → Codex



This file indexes where each weekly `Placement.md` lives, and provides the template.



\- W34 → /Logs/Weekly/2025-W34/Placement.md

\- W35 → /Logs/Weekly/2025-W35/Placement.md

\- W36 → /Logs/Weekly/2025-W36/Placement.md

...

